package com.cosmetic.cosmetic_common.utility;

public class CacheNames {

    public static final String COSMETIC_MASTER = "cosmetic-master";
    
    public static final String PRODUCT_MASTER = "product-master";
    
    public static final String USER_MASTER = "user-master";
}
