package com.cosmetic.cosmetic_common.dto;

import java.io.Serializable;

public class CommonDto implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 6176289237021002494L;

}
