package com.cosmetic.cosmetic_common.utility;

public class TransactionTypes {

    public static final String BUY = "buy";
    public static final String SELL = "sell";
}
